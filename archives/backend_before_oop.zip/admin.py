from flask import Blueprint, jsonify, request
from uuid import uuid4
from datetime import datetime
import re
from auth import require_auth, hash_password
from database import get_db


admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")


# =========================================================
# DASHBOARD
# =========================================================

@admin_bp.get("/dashboard")
@require_auth("admin")
def dashboard():
    db = get_db()
    try:
        counts = db.fetch_one("""
            select
                (select count(*) from students) as total_students,
                (select count(*) from lecturers where exists (
                    select 1 from users u where u.user_id=lecturers.user_id and u.active_status=true
                )) as active_lecturers,
                (select count(*) from courses) as total_courses,
                (select count(*) from registrations where registration_status='registered') as active_registrations
        """)
        semester = db.fetch_one("""
            select semester_id, semester_name, start_date, end_date
            from semesters
            where current_date between start_date and end_date
            order by start_date desc
            limit 1
        """)
        return jsonify({**(counts or {}), "active_semester": semester})
    finally:
        db.close()


# =========================================================
# USER
# =========================================================

@admin_bp.get("/users")
@require_auth("admin")
def list_users():

    db = get_db()

    try:
        users = db.fetch_all("""
            select u.user_id, u.username, u.fullname, u.email, u.role, u.active_status as status,
                   s.student_id, s.major_code, l.lecturer_id,
                   coalesce(array_agg(distinct q.course_code) filter (where q.course_code is not null), '{}') as qualifications
            from users u
            left join students s on s.user_id=u.user_id
            left join lecturers l on l.user_id=u.user_id
            left join lecturer_qualifications q on q.lecturer_id=l.lecturer_id
            group by u.user_id,u.username,u.fullname,u.email,u.role,u.active_status,s.student_id,s.major_code,l.lecturer_id
            order by u.role, u.user_id
        """)

        return jsonify(users)

    finally:
        db.close()


# Admin creates Lecturer or Student account
@admin_bp.post("/users")
@require_auth("admin")
def create_user():

    data = request.get_json() or {}

    user_id = data.get("user_id")
    fullname = data.get("fullname")
    email = data.get("email")
    password = data.get("password")
    role = data.get("role")

    # Check required information
    if not user_id or not fullname or not email or not password or not role:
        return jsonify({"error": "Missing required information"}), 400
    if not re.match(r"^[^\s@]+@[^\s@]+\.[^\s@]+$", str(email).strip()):
        return jsonify({"error": "Invalid email address"}), 400
    if len(str(password)) < 8:
        return jsonify({"error": "Password must be at least 8 characters"}), 400

    # Admin can only create Lecturer or Student
    if role not in ["lecturer", "student"]:
        return jsonify({
            "error": "Admin can only create lecturer or student"
        }), 400

    # Username is automatically created from user ID
    username = user_id.lower()

    db = get_db()

    try:
        # Validate role-specific data before creating the parent user row.
        major_code = data.get("major_code")
        dob = data.get("dob")
        if role == "student":
            if not major_code:
                return jsonify({"error": "Major is required for student"}), 400
            major = db.fetch_one("select major_code from majors where major_code=%s", (major_code,))
            if not major:
                return jsonify({"error": "Major does not exist"}), 400

        # Check duplicate user ID, username or email
        old_user = db.fetch_one("""
            select user_id
            from users
            where user_id = %s
               or username = %s
               or email = %s
        """, (user_id, username, email))

        if old_user:
            return jsonify({
                "error": "User ID, username or email already exists"
            }), 409

        # -------------------------------------------------
        # Create record in users table
        # -------------------------------------------------

        db.execute("""
            insert into users
            (user_id, username, password, fullname, email, role)
            values (%s, %s, %s, %s, %s, %s)
        """, (
            user_id,
            username,
            hash_password(password),
            fullname,
            email,
            role
        ))

        # -------------------------------------------------
        # Create Lecturer
        # -------------------------------------------------

        if role == "lecturer":
            db.execute("""
                insert into lecturers
                (lecturer_id, user_id)
                values (%s, %s)
            """, (user_id, user_id))

            qualifications = data.get("qualifications") or []
            if not isinstance(qualifications, list):
                raise ValueError("qualifications must be a list")
            for course_code in dict.fromkeys(str(x).strip() for x in qualifications if str(x).strip()):
                if not db.fetch_one("select course_code from courses where course_code=%s", (course_code,)):
                    raise ValueError(f"Course does not exist: {course_code}")
                db.execute("""
                    insert into lecturer_qualifications (qualification_id, lecturer_id, course_code)
                    values (%s, %s, %s)
                """, (uuid4().hex[:20], user_id, course_code))

        # -------------------------------------------------
        # Create Student
        # -------------------------------------------------

        if role == "student":

            # major_code and dob were validated before creating the user.

            db.execute("""
                insert into students
                (student_id, user_id, dob, major_code)
                values (%s, %s, %s, %s)
            """, (
                user_id,
                user_id,
                dob,
                major_code
            ))

        db.conn.commit()
        return jsonify({
            "message": "User created successfully",
            "user_id": user_id,
            "username": username,
            "role": role
        }), 201

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Could not create user"
        }), 400

    finally:
        db.close()


# Update user information
@admin_bp.put("/users/<user_id>")
@require_auth("admin")
def update_user(user_id):
    data = request.get_json() or {}
    fullname = data.get("fullname")
    email = data.get("email")
    major_code = data.get("major_code")
    status = data.get("status")
    qualifications = data.get("qualifications", None)
    if fullname is None and email is None and major_code is None and status is None and qualifications is None:
        return jsonify({"error": "Nothing to update"}), 400
    db=get_db()
    try:
        user=db.fetch_one("select user_id, role from users where user_id=%s", (user_id,))
        if not user: return jsonify({"error":"User not found"}),404
        if email:
            email = str(email).strip()
            if not re.match(r"^[^\s@]+@[^\s@]+\.[^\s@]+$", email):
                return jsonify({"error":"Invalid email address"}),400
            dup=db.fetch_one("select user_id from users where email=%s and user_id<>%s", (email,user_id))
            if dup: return jsonify({"error":"Email already exists"}),409
        if status is not None and status not in ("Active","Inactive", "active", "inactive"):
            return jsonify({"error":"Invalid status"}),400
        if major_code is not None:
            if user["role"] != "student": return jsonify({"error":"Major can only be changed for students"}),400
            if not db.fetch_one("select major_code from majors where major_code=%s", (major_code,)):
                return jsonify({"error":"Major does not exist"}),400
        if qualifications is not None:
            if user["role"] != "lecturer" or not isinstance(qualifications, list):
                return jsonify({"error":"Qualifications can only be changed for lecturers"}),400
            clean_qualifications = list(dict.fromkeys(str(x).strip() for x in qualifications if str(x).strip()))
            for course_code in clean_qualifications:
                if not db.fetch_one("select course_code from courses where course_code=%s", (course_code,)):
                    return jsonify({"error":f"Course does not exist: {course_code}"}),400
        db.execute("""update users set fullname=coalesce(%s,fullname), email=coalesce(%s,email),
            active_status=coalesce(%s,active_status) where user_id=%s""",
            (fullname,email,(str(status).lower() == "active") if status is not None else None,user_id))
        if major_code is not None:
            db.execute("update students set major_code=%s where user_id=%s", (major_code,user_id))
        if qualifications is not None:
            db.execute("""
                delete from lecturer_qualifications
                where lecturer_id=(select lecturer_id from lecturers where user_id=%s)
            """, (user_id,))
            for course_code in clean_qualifications:
                db.execute("""
                    insert into lecturer_qualifications (qualification_id, lecturer_id, course_code)
                    values (%s, (select lecturer_id from lecturers where user_id=%s), %s)
                """, (uuid4().hex[:20], user_id, course_code))
        db.conn.commit()
        return jsonify({"message":"User updated successfully"})
    except Exception:
        db.conn.rollback(); return jsonify({"error":"Could not update user"}),400
    finally: db.close()


@admin_bp.delete("/users/<user_id>")
@require_auth("admin")
def deactivate_user(user_id):
    db=get_db()
    try:
        row=db.fetch_one("select role from users where user_id=%s",(user_id,))
        if not row: return jsonify({"error":"User not found"}),404
        if row["role"]=="admin": return jsonify({"error":"Administrator cannot be deactivated"}),400
        db.execute("update users set active_status=false where user_id=%s",(user_id,)); db.conn.commit()
        return jsonify({"message":"User deactivated successfully"})
    finally: db.close()


# =========================================================
# MAJOR
# =========================================================

@admin_bp.get("/majors")
@require_auth("admin")
def list_majors():

    db = get_db()

    try:

        majors = db.fetch_all("""
            select major_code, major_name
            from majors
            order by major_code
        """)

        return jsonify(majors)

    finally:
        db.close()


@admin_bp.post("/majors")
@require_auth("admin")
def create_major():

    data = request.get_json() or {}

    major_code = data.get("major_code")
    major_name = data.get("major_name")

    if not major_code or not major_name:
        return jsonify({
            "error": "Major code and major name are required"
        }), 400

    db = get_db()

    try:

        db.execute_query("""
            insert into majors
            (major_code, major_name)
            values (%s, %s)
        """, (
            major_code,
            major_name
        ))

        return jsonify({
            "message": "Major created successfully"
        }), 201

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Major code already exists or data is invalid"
        }), 409

    finally:
        db.close()


@admin_bp.put("/majors/<major_code>")
@require_auth("admin")
def update_major(major_code):

    data = request.get_json() or {}

    major_name = data.get("major_name")

    if not major_name:
        return jsonify({
            "error": "Major name is required"
        }), 400

    db = get_db()

    try:

        db.execute_query("""
            update majors
            set major_name = %s
            where major_code = %s
        """, (
            major_name,
            major_code
        ))

        return jsonify({
            "message": "Major updated successfully"
        })

    finally:
        db.close()


@admin_bp.delete("/majors/<major_code>")
@require_auth("admin")
def delete_major(major_code):

    db = get_db()

    try:

        db.execute_query("""
            delete from majors
            where major_code = %s
        """, (major_code,))

        return jsonify({
            "message": "Major deleted successfully"
        })

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Major is still referenced by existing data"
        }), 409

    finally:
        db.close()


# =========================================================
# COURSE
# =========================================================

@admin_bp.get("/courses")
@require_auth("admin")
def list_courses():

    db = get_db()

    try:

        courses = db.fetch_all("""
            select
                c.course_code,
                c.course_name,
                c.credit,
                c.prerequisite_course_code,
                p.course_name as prerequisite_name,
                c.max_capacity
            from courses c
            left join courses p
                on p.course_code = c.prerequisite_course_code
            order by c.course_code
        """)

        return jsonify(courses)

    finally:
        db.close()


@admin_bp.post("/courses")
@require_auth("admin")
def create_course():

    data = request.get_json() or {}

    course_code = data.get("course_code")
    course_name = data.get("course_name")
    credit = data.get("credit")
    prerequisite = data.get("prerequisite_course_code")
    max_capacity = data.get("max_capacity")

    if not course_code or not course_name or credit is None or max_capacity is None:
        return jsonify({
            "error": "Missing course information"
        }), 400

    if int(credit) <= 0 or int(max_capacity) <= 0:
        return jsonify({
            "error": "Credit and capacity must be positive"
        }), 400

    if prerequisite == course_code:
        return jsonify({
            "error": "A course cannot be its own prerequisite"
        }), 400

    db = get_db()

    try:

        db.execute_query("""
            insert into courses
            (
                course_code,
                course_name,
                credit,
                prerequisite_course_code,
                max_capacity
            )
            values (%s, %s, %s, %s, %s)
        """, (
            course_code,
            course_name,
            credit,
            prerequisite,
            max_capacity
        ))

        return jsonify({
            "message": "Course created successfully"
        }), 201

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Invalid course or duplicate course code"
        }), 409

    finally:
        db.close()


@admin_bp.put("/courses/<course_code>")
@require_auth("admin")
def update_course(course_code):

    data = request.get_json() or {}

    prerequisite = data.get("prerequisite_course_code")

    if prerequisite == course_code:
        return jsonify({
            "error": "A course cannot be its own prerequisite"
        }), 400

    db = get_db()

    try:

        current = db.fetch_one("select course_name, credit, max_capacity from courses where course_code=%s", (course_code,))
        if not current: return jsonify({"error":"Course not found"}),404
        course_name = data.get("course_name", current["course_name"])
        credit = data.get("credit", current["credit"])
        max_capacity = data.get("max_capacity", current["max_capacity"])
        if int(credit) <= 0 or int(max_capacity) <= 0: return jsonify({"error":"Credit and capacity must be positive"}),400
        db.execute_query("""update courses set course_name=%s, credit=%s, prerequisite_course_code=%s, max_capacity=%s where course_code=%s""",
            (course_name,credit,prerequisite,max_capacity,course_code))

        return jsonify({
            "message": "Course updated successfully"
        })

    finally:
        db.close()


@admin_bp.delete("/courses/<course_code>")
@require_auth("admin")
def delete_course(course_code):

    db = get_db()

    try:

        db.execute_query("""
            delete from courses
            where course_code = %s
        """, (course_code,))

        return jsonify({
            "message": "Course deleted successfully"
        })

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Course is still referenced by existing data"
        }), 409

    finally:
        db.close()


# =========================================================
# CURRICULUM
# =========================================================

@admin_bp.get("/curriculum/<major_code>")
@require_auth("admin")
def get_curriculum(major_code):

    db = get_db()

    try:

        curriculum = db.fetch_all("""
            select
                cu.curriculum_id,
                cu.major_code,
                cu.course_code,
                c.course_name,
                c.credit,
                c.prerequisite_course_code,
                cu.recommended_semester
            from curriculum cu
            join courses c
                on c.course_code = cu.course_code
            where cu.major_code = %s
            order by cu.recommended_semester, cu.course_code
        """, (major_code,))

        return jsonify(curriculum)

    finally:
        db.close()


@admin_bp.post("/curriculum")
@require_auth("admin")
def add_curriculum():

    data = request.get_json() or {}

    curriculum_id = data.get("curriculum_id") or uuid4().hex[:20]
    major_code = data.get("major_code")
    course_code = data.get("course_code")
    semester = data.get("recommended_semester")

    if not curriculum_id or not major_code or not course_code:
        return jsonify({
            "error": "Missing curriculum information"
        }), 400

    db = get_db()

    try:

        db.execute_query("""
            insert into curriculum
            (
                curriculum_id,
                major_code,
                course_code,
                recommended_semester
            )
            values (%s, %s, %s, %s)
        """, (
            curriculum_id,
            major_code,
            course_code,
            semester
        ))

        return jsonify({
            "message": "Course added to curriculum"
        }), 201

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Invalid data or course already exists in this major"
        }), 409

    finally:
        db.close()


@admin_bp.put("/curriculum/<curriculum_id>")
@require_auth("admin")
def update_curriculum(curriculum_id):

    data = request.get_json() or {}

    db = get_db()

    try:

        db.execute_query("""
            update curriculum
            set recommended_semester = %s
            where curriculum_id = %s
        """, (
            data.get("recommended_semester"),
            curriculum_id
        ))

        return jsonify({
            "message": "Curriculum updated successfully"
        })

    finally:
        db.close()


@admin_bp.delete("/curriculum/<curriculum_id>")
@require_auth("admin")
def remove_curriculum(curriculum_id):

    db = get_db()

    try:

        db.execute_query("""
            delete from curriculum
            where curriculum_id = %s
        """, (curriculum_id,))

        return jsonify({
            "message": "Course removed from curriculum"
        })

    finally:
        db.close()


# =========================================================
# SEMESTER
# =========================================================

@admin_bp.get("/semesters")
@require_auth("admin")
def list_semesters():

    db = get_db()

    try:

        semesters = db.fetch_all("""
            select semester_id, semester_name, start_date, end_date,
                   case when current_date < start_date then 'upcoming'
                        when current_date <= end_date then 'active'
                        else 'completed' end as status
            from semesters
            order by start_date desc
        """)

        return jsonify(semesters)

    finally:
        db.close()


@admin_bp.post("/semesters")
@require_auth("admin")
def create_semester():

    data = request.get_json() or {}

    semester_id = data.get("semester_id") or uuid4().hex[:20]
    semester_name = data.get("semester_name")
    start_date = data.get("start_date")
    end_date = data.get("end_date")

    if not semester_id or not semester_name or not start_date or not end_date:
        return jsonify({
            "error": "Missing semester information"
        }), 400

    start_date = str(start_date)[:10]
    end_date = str(end_date)[:10]
    if start_date >= end_date:
        return jsonify({
            "error": "Start date must be earlier than end date"
        }), 400

    db = get_db()

    try:

        overlap = db.fetch_one("""
            select 1
            from semesters
            where start_date < %s
              and end_date > %s
        """, (
            end_date,
            start_date
        ))

        if overlap:
            return jsonify({
                "error": "Semester overlaps an existing semester"
            }), 409

        db.execute_query("""
            insert into semesters
            (
                semester_id,
                semester_name,
                start_date,
                end_date,
                status
            )
            values (%s, %s, %s, %s, %s)
        """, (
            semester_id,
            semester_name,
            start_date,
            end_date,
            "upcoming"
        ))

        return jsonify({
            "message": "Semester created successfully"
        }), 201

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Invalid semester"
        }), 409

    finally:
        db.close()


@admin_bp.put("/semesters/<semester_id>")
@require_auth("admin")
def update_semester(semester_id):

    data = request.get_json() or {}

    start_date = data.get("start_date")
    end_date = data.get("end_date")

    if not start_date or not end_date:
        return jsonify({
            "error": "Start date and end date are required"
        }), 400

    start_date = str(start_date)[:10]
    end_date = str(end_date)[:10]
    if start_date >= end_date:
        return jsonify({
            "error": "Start date must be earlier than end date"
        }), 400

    db = get_db()

    try:

        overlap = db.fetch_one("""
            select 1
            from semesters
            where semester_id <> %s
              and start_date < %s
              and end_date > %s
        """, (
            semester_id,
            end_date,
            start_date
        ))

        if overlap:
            return jsonify({
                "error": "Semester overlaps an existing semester"
            }), 409

        db.execute_query("""
            update semesters
            set semester_name = %s,
                start_date = %s,
                end_date = %s,
                status = %s
            where semester_id = %s
        """, (
            data.get("semester_name"),
            start_date,
            end_date,
            data.get("status", "upcoming"),
            semester_id
        ))

        return jsonify({
            "message": "Semester updated successfully"
        })

    finally:
        db.close()


@admin_bp.delete("/semesters/<semester_id>")
@require_auth("admin")
def delete_semester(semester_id):

    db = get_db()

    try:

        db.execute_query("""
            delete from semesters
            where semester_id = %s
        """, (semester_id,))

        return jsonify({
            "message": "Semester deleted successfully"
        })

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Semester is still referenced"
        }), 409

    finally:
        db.close()


# =========================================================
# REGISTRATION PERIOD
# =========================================================

@admin_bp.get("/registration-periods")
@require_auth("admin")
def list_periods():

    db = get_db()

    try:

        periods = db.fetch_all("""
            select
                rp.*,
                s.semester_name,
                case
                    when current_date < rp.start_date
                        then 'upcoming'
                    when current_date <= rp.end_date
                        then 'open'
                    else 'closed'
                end as current_status
            from registration_periods rp
            join semesters s
                on s.semester_id = rp.semester_id
            order by rp.start_date desc
        """)

        return jsonify(periods)

    finally:
        db.close()


@admin_bp.post("/registration-periods")
@require_auth("admin")
def create_period():

    data = request.get_json() or {}

    semester_id = data.get("semester_id")
    period_id = data.get("period_id") or uuid4().hex[:20]
    period_name = data.get("period_name") or "Registration Period"
    start_date = data.get("start_date")
    end_date = data.get("end_date")

    if not semester_id or not period_id or not period_name:
        return jsonify({
            "error": "Missing registration period information"
        }), 400

    if not start_date or not end_date:
        return jsonify({
            "error": "Start date and end date are required"
        }), 400

    start_date = str(start_date)[:10]
    end_date = str(end_date)[:10]
    if start_date >= end_date:
        return jsonify({
            "error": "Start date must be earlier than end date"
        }), 400

    db = get_db()

    try:

        semester = db.fetch_one("""
            select start_date, end_date
            from semesters
            where semester_id = %s
        """, (semester_id,))

        if not semester:
            return jsonify({
                "error": "Semester not found"
            }), 404

        

        db.execute_query("""
            insert into registration_periods
            (
                period_id,
                semester_id,
                period_name,
                start_date,
                end_date
            )
            values (%s, %s, %s, %s, %s)
        """, (
            period_id,
            semester_id,
            period_name,
            start_date,
            end_date
        ))

        return jsonify({
            "message": "Registration period created successfully"
        }), 201

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Invalid registration period"
        }), 409

    finally:
        db.close()


@admin_bp.put("/registration-periods/<period_id>")
@require_auth("admin")
def update_period(period_id):

    data = request.get_json() or {}

    semester_id = data.get("semester_id")
    period_name = data.get("period_name") or "Registration Period"
    start_date = data.get("start_date")
    end_date = data.get("end_date")

    if not semester_id or not period_name:
        return jsonify({
            "error": "Missing registration period information"
        }), 400

    if not start_date or not end_date:
        return jsonify({
            "error": "Start date and end date are required"
        }), 400

    start_date = str(start_date)[:10]
    end_date = str(end_date)[:10]
    if start_date >= end_date:
        return jsonify({
            "error": "Start date must be earlier than end date"
        }), 400

    db = get_db()

    try:

        semester = db.fetch_one("""
            select start_date, end_date
            from semesters
            where semester_id = %s
        """, (semester_id,))

        if not semester:
            return jsonify({
                "error": "Semester not found"
            }), 404

        if (
            start_date < str(semester["start_date"])
            or end_date > str(semester["end_date"])
        ):
            return jsonify({
                "error": "Registration period must fall within the semester"
            }), 400

        db.execute_query("""
            update registration_periods
            set semester_id = %s,
                period_name = %s,
                start_date = %s,
                end_date = %s
            where period_id = %s
        """, (
            semester_id,
            period_name,
            start_date,
            end_date,
            period_id
        ))

        return jsonify({
            "message": "Registration period updated successfully"
        })

    finally:
        db.close()


@admin_bp.delete("/registration-periods/<period_id>")
@require_auth("admin")
def delete_period(period_id):

    db = get_db()

    try:

        db.execute_query("""
            delete from registration_periods
            where period_id = %s
        """, (period_id,))

        return jsonify({
            "message": "Registration period deleted successfully"
        })

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Registration period is still referenced"
        }), 409

    finally:
        db.close()


# =========================================================
# REGISTRATION DEMAND
# =========================================================

@admin_bp.get("/registration-demand")
@require_auth("admin")
def registration_demand():

    period_id = request.args.get("period_id")
    major_code = request.args.get("major_code")

    if not period_id:
        return jsonify({"error": "period_id is required"}), 400

    db = get_db()

    try:

        demand = db.fetch_all("""
            select
                c.course_code,
                c.course_name,
                count(distinct r.registration_id)
                filter (
                    where r.registration_status = 'registered'
                ) as registered_students
            from curriculum cu
            join courses c
                on c.course_code = cu.course_code
            left join registrations r
                on r.course_code = c.course_code
               and r.period_id = %s
            where (%s is null or cu.major_code = %s)
            group by c.course_code, c.course_name
            order by c.course_code
        """, (
            period_id,
            major_code,
            major_code
        ))

        return jsonify(demand)

    finally:
        db.close()


@admin_bp.get("/registration-demand/<course_code>/students")
@require_auth("admin")
def demand_students(course_code):

    period_id = request.args.get("period_id")

    if not period_id:
        return jsonify({
            "error": "period_id is required"
        }), 400

    db = get_db()

    try:

        students = db.fetch_all("""
            select
                s.student_id,
                u.fullname,
                u.email,
                r.registration_status
            from registrations r
            join students s
                on s.student_id = r.student_id
            join users u
                on u.user_id = s.user_id
            where r.period_id = %s
              and r.course_code = %s
              and r.registration_status = 'registered'
            order by s.student_id
        """, (
            period_id,
            course_code
        ))

        return jsonify(students)

    finally:
        db.close()


# =========================================================
# TEACHING ASSIGNMENT
# =========================================================

@admin_bp.get("/teaching-assignments")
@require_auth("admin")
def list_assignments():

    semester_id = request.args.get("semester_id")

    db = get_db()

    try:

        assignments = db.fetch_all("""
            select
                ta.assignment_id,
                ta.semester_id,
                ta.lecturer_id,
                ta.course_code,
                u.fullname as lecturer_name,
                c.course_name,
                s.semester_name
            from teaching_assignments ta
            join lecturers l
                on l.lecturer_id = ta.lecturer_id
            join users u
                on u.user_id = l.user_id
            join courses c
                on c.course_code = ta.course_code
            join semesters s
                on s.semester_id = ta.semester_id
            where (%s is null or ta.semester_id = %s)
            order by s.start_date desc, c.course_code
        """, (
            semester_id,
            semester_id
        ))

        return jsonify(assignments)

    finally:
        db.close()


@admin_bp.delete("/teaching-assignments/<assignment_id>")
@require_auth("admin")
def delete_assignment(assignment_id):

    db = get_db()

    try:

        db.execute_query("""
            delete from teaching_assignments
            where assignment_id = %s
        """, (assignment_id,))

        return jsonify({
            "message": "Teaching assignment deleted successfully"
        })

    finally:
        db.close()


# =========================================================
# LECTURER QUALIFICATION
# =========================================================

@admin_bp.get("/qualified-lecturers/<course_code>")
@require_auth("admin")
def qualified_lecturers(course_code):

    db = get_db()

    try:

        lecturers = db.fetch_all("""
            select
                l.lecturer_id,
                u.fullname,
                u.email
            from lecturer_qualifications q
            join lecturers l
                on l.lecturer_id = q.lecturer_id
            join users u
                on u.user_id = l.user_id
            where q.course_code = %s
              and exists (select 1 from users au where au.user_id=l.user_id and au.active_status=true)
            order by l.lecturer_id
        """, (course_code,))

        return jsonify(lecturers)

    finally:
        db.close()


@admin_bp.post("/lecturer-qualifications")
@require_auth("admin")
def add_qualification():

    data = request.get_json() or {}

    qualification_id = data.get("qualification_id") or uuid4().hex[:20]
    lecturer_id = data.get("lecturer_id")
    course_code = data.get("course_code")

    if not qualification_id or not lecturer_id or not course_code:
        return jsonify({
            "error": "Missing qualification information"
        }), 400

    db = get_db()

    try:

        db.execute_query("""
            insert into lecturer_qualifications
            (
                qualification_id,
                lecturer_id,
                course_code
            )
            values (%s, %s, %s)
        """, (
            qualification_id,
            lecturer_id,
            course_code
        ))

        return jsonify({
            "message": "Qualification added successfully"
        }), 201

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Invalid or duplicate qualification"
        }), 409

    finally:
        db.close()


@admin_bp.delete("/lecturer-qualifications/<lecturer_id>/<course_code>")
@require_auth("admin")
def remove_qualification(lecturer_id, course_code):
    db = get_db()
    try:
        row = db.fetch_one("""
            select qualification_id
            from lecturer_qualifications
            where lecturer_id=%s and course_code=%s
        """, (lecturer_id, course_code))
        if not row:
            return jsonify({"error": "Qualification not found"}), 404
        db.execute_query("delete from lecturer_qualifications where lecturer_id=%s and course_code=%s", (lecturer_id, course_code))
        return jsonify({"message": "Qualification removed successfully"})
    finally:
        db.close()


# =========================================================
# ASSIGN LECTURER TO COURSE
# =========================================================

@admin_bp.post("/teaching-assignments")
@require_auth("admin")
def assign_lecturer():

    data = request.get_json() or {}

    assignment_id = data.get("assignment_id") or uuid4().hex[:20]
    semester_id = data.get("semester_id")
    lecturer_id = data.get("lecturer_id")
    course_code = data.get("course_code")

    if not assignment_id or not semester_id or not lecturer_id or not course_code:
        return jsonify({
            "error": "Missing assignment information"
        }), 400

    db = get_db()

    try:

        # Check lecturer qualification
        qualified = db.fetch_one("""
            select 1
            from lecturer_qualifications
            where lecturer_id = %s
              and course_code = %s
        """, (
            lecturer_id,
            course_code
        ))

        if not qualified:
            return jsonify({
                "error": "Lecturer is not qualified for this course"
            }), 400

        db.execute_query("""
            insert into teaching_assignments
            (
                assignment_id,
                semester_id,
                lecturer_id,
                course_code
            )
            values (%s, %s, %s, %s)
        """, (
            assignment_id,
            semester_id,
            lecturer_id,
            course_code
        ))

        return jsonify({
            "message": "Lecturer assigned successfully"
        }), 201

    except Exception:

        db.conn.rollback()

        return jsonify({
            "error": "Invalid assignment or duplicate assignment"
        }), 409

    finally:
        db.close()