from flask import Blueprint, jsonify, request
from uuid import uuid4
from auth import require_auth, get_current_user
from database import get_db

student_bp = Blueprint("student", __name__, url_prefix="/api/student")


@student_bp.get("/profile")
@require_auth("student")
def profile():
    user = get_current_user(); db = get_db()
    try:
        row = db.fetch_one("""select s.student_id, s.major_code, u.user_id, u.username, u.fullname, u.email, u.role
            from students s join users u on u.user_id=s.user_id where s.user_id=%s""", (user["user_id"],))
        return (jsonify(row), 200) if row else (jsonify({"error":"student profile not found"}), 404)
    finally: db.close()

@student_bp.get("/semesters")
@require_auth("student")
def semesters():
    db=get_db()
    try: return jsonify(db.fetch_all("select semester_id, semester_name, start_date, end_date, status from semesters order by start_date desc"))
    finally: db.close()

@student_bp.get("/registration-periods")
@require_auth("student")
def registration_periods():
    db=get_db()
    try: return jsonify(db.fetch_all("""select rp.*, case when current_date < rp.start_date then 'upcoming' when current_date <= rp.end_date then 'open' else 'closed' end as current_status from registration_periods rp order by rp.start_date desc"""))
    finally: db.close()


@student_bp.get("/curriculum")
@require_auth("student")
def curriculum():
    user=get_current_user(); db=get_db()
    try:
        return jsonify(db.fetch_all("""select cu.curriculum_id, cu.major_code, cu.course_code, c.course_name, c.credit,
            c.prerequisite_course_code, cu.recommended_semester from students s
            join curriculum cu on cu.major_code=s.major_code join courses c on c.course_code=cu.course_code
            where s.user_id=%s order by cu.recommended_semester, cu.course_code""", (user["user_id"],)))
    finally: db.close()


@student_bp.get("/courses")
@require_auth("student")
def courses():
    student = get_current_user()
    search = request.args.get("search", "").strip()
    period_id = request.args.get("period_id")
    db = get_db()
    try:
        st = db.fetch_one("select student_id from students where user_id=%s", (student["user_id"],))
        if not st:
            return jsonify({"error": "student profile not found"}), 404
        return jsonify(db.fetch_all("""
            select c.course_code, c.course_name, c.credit,
                   c.prerequisite_course_code, pc.course_name as prerequisite_name,
                   cu.recommended_semester, c.max_capacity,
                   c.max_capacity - count(r.registration_id) filter (where r.registration_status='registered') as available_seats,
                   case when c.prerequisite_course_code is null then 'N/A'
                        when exists (select 1 from registrations pr where pr.student_id=s.student_id and pr.course_code=c.prerequisite_course_code and pr.result_status='passed') then 'Satisfied'
                        else 'Not Satisfied' end as prerequisite_status,
                   case when exists (select 1 from registrations sr where sr.student_id=s.student_id and sr.course_code=c.course_code and sr.period_id=%s and sr.registration_status='registered') then 'Registered' else 'Available' end as reg_status
            from students s
            join curriculum cu on cu.major_code=s.major_code
            join courses c on c.course_code=cu.course_code
            left join courses pc on pc.course_code=c.prerequisite_course_code
            left join registrations r on r.course_code=c.course_code and r.period_id=%s
            where s.student_id=%s
              and (c.course_code ilike %s or c.course_name ilike %s)
              and not exists (
                  select 1 from registrations r2
                  where r2.student_id=s.student_id and r2.course_code=c.course_code and r2.period_id=%s
                    and r2.registration_status='registered'
              )
              and not exists (
                  select 1 from registrations r3
                  where r3.student_id=s.student_id and r3.course_code=c.course_code
                    and r3.result_status='passed'
              )
            group by c.course_code, c.course_name, c.credit, c.prerequisite_course_code,
                     pc.course_name, cu.recommended_semester, c.max_capacity, s.student_id
            order by c.course_code
        """, (period_id, period_id, st["student_id"], f"%{search}%", f"%{search}%", period_id)))
    finally:
        db.close()


@student_bp.post("/registrations")
@require_auth("student")
def register_course():
    student = get_current_user()
    d = request.get_json() or {}
    course_code = d.get("course_code")
    period_id = d.get("period_id")
    if not course_code or not period_id:
        return jsonify({"error": "course_code and period_id are required"}), 400

    db = get_db()
    try:
        # Lock the course row so simultaneous registrations cannot overbook it.
        course = db.fetch_one("select * from courses where course_code=%s for update", (course_code,))
        if not course:
            db.conn.rollback()
            return jsonify({"error": "course not found"}), 404

        period = db.fetch_one("""select * from registration_periods
            where period_id=%s and current_date between start_date and end_date for update""", (period_id,))
        if not period:
            db.conn.rollback()
            return jsonify({"error": "registration period is not open"}), 400

        st = db.fetch_one("select student_id, major_code from students where user_id=%s", (student["user_id"],))
        if not st:
            db.conn.rollback()
            return jsonify({"error": "student profile not found"}), 404

        eligible = db.fetch_one("select 1 from curriculum where major_code=%s and course_code=%s",
                                (st["major_code"], course_code))
        if not eligible:
            db.conn.rollback()
            return jsonify({"error": "course does not belong to student's curriculum"}), 400

        duplicate = db.fetch_one("""select 1 from registrations
            where student_id=%s and course_code=%s and period_id=%s and registration_status='registered'""",
            (st["student_id"], course_code, period_id))
        if duplicate:
            db.conn.rollback()
            return jsonify({"error": "student is already registered for this course"}), 409

        passed = db.fetch_one("""select 1 from registrations
            where student_id=%s and course_code=%s and result_status='passed'""",
            (st["student_id"], course_code))
        if passed:
            db.conn.rollback()
            return jsonify({"error": "student has already completed this course"}), 400

        if course["prerequisite_course_code"]:
            pre = db.fetch_one("""select 1 from registrations
                where student_id=%s and course_code=%s and result_status='passed'""",
                (st["student_id"], course["prerequisite_course_code"]))
            if not pre:
                db.conn.rollback()
                return jsonify({"error": "prerequisite is not satisfied"}), 400

        count = db.fetch_one("""select count(*) as registered_count from registrations
            where course_code=%s and period_id=%s and registration_status='registered'""",
            (course_code, period_id))["registered_count"]
        if count >= course["max_capacity"]:
            db.conn.rollback()
            return jsonify({"error": "course capacity has been reached"}), 409

        existing = db.fetch_one("""select registration_id from registrations
            where student_id=%s and period_id=%s and course_code=%s""",
            (st["student_id"], period_id, course_code))
        if existing:
            registration_id = existing["registration_id"]
            db.execute("""update registrations set registration_status='registered', grade=null, result_status=null
                where registration_id=%s""", (registration_id,))
        else:
            registration_id = (d.get("registration_id") or uuid4().hex)[:20]
            db.execute("""insert into registrations
                (registration_id, student_id, period_id, course_code, registration_status)
                values(%s,%s,%s,%s,'registered')""",
                (registration_id, st["student_id"], period_id, course_code))
        db.conn.commit()
        return jsonify({"message": "course registered successfully", "registration_id": registration_id}), 201
    except Exception as exc:
        db.conn.rollback()
        return jsonify({"error": "registration failed", "detail": str(exc)}), 409
    finally:
        db.close()


@student_bp.get("/registrations")
@require_auth("student")
def registrations():
    student = get_current_user()
    semester_id = request.args.get("semester_id")
    db = get_db()
    try:
        return jsonify(db.fetch_all("""
            select r.registration_id, c.course_code, c.course_name, c.credit,
                   initcap(r.registration_status) as status, c.max_capacity,
                   (c.max_capacity - (select count(*) from registrations rr where rr.course_code=r.course_code and rr.period_id=r.period_id and rr.registration_status='registered')) as available_seats,
                   rp.start_date as registration_start_date,
                   rp.end_date as registration_end_date,
                   case when current_date < rp.start_date then 'upcoming'
                        when current_date <= rp.end_date then 'open'
                        else 'closed' end as current_registration_status
            from registrations r
            join students s on s.student_id=r.student_id
            join courses c on c.course_code=r.course_code
            join registration_periods rp on rp.period_id=r.period_id
            where s.user_id=%s and (%s is null or rp.semester_id=%s)
            order by rp.start_date desc, c.course_code
        """, (student["user_id"], semester_id, semester_id)))
    finally:
        db.close()


@student_bp.put("/registrations/<registration_id>/drop")
@require_auth("student")
def drop_course(registration_id):
    student = get_current_user()
    db = get_db()
    try:
        row = db.fetch_one("""
            select r.registration_id, r.registration_status, s.student_id,
                   rp.start_date, rp.end_date
            from registrations r
            join students s on s.student_id=r.student_id
            join registration_periods rp on rp.period_id=r.period_id
            where r.registration_id=%s and s.user_id=%s
        """, (registration_id, student["user_id"]))
        if not row:
            return jsonify({"error": "registration not found"}), 404
        if row["registration_status"] != "registered":
            return jsonify({"error": "course is not currently registered"}), 400
        # With the current ERD, the registration period dates are the only configured dates.
        if not (row["start_date"] <= __import__("datetime").date.today() <= row["end_date"]):
            return jsonify({"error": "drop period is not open"}), 400
        db.execute("update registrations set registration_status='dropped' where registration_id=%s", (registration_id,))
        db.conn.commit()
        return jsonify({"message": "course dropped successfully"})
    finally:
        db.close()


@student_bp.get("/grades")
@require_auth("student")
def grades():
    student = get_current_user()
    semester_id = request.args.get("semester_id")
    db = get_db()
    try:
        st = db.fetch_one("select student_id from students where user_id=%s", (student["user_id"],))
        if not st:
            return jsonify({"error": "student profile not found"}), 404
        return jsonify(db.fetch_all("""
            select c.course_code, c.course_name, c.credit, r.grade,
                   s.semester_name,
                   case when r.grade is null then null
                        when r.grade >= 5 then 'passed'
                        else 'not passed' end as result_status
            from registrations r
            join students st on st.student_id=r.student_id
            join courses c on c.course_code=r.course_code
            join registration_periods rp on rp.period_id=r.period_id
            join semesters s on s.semester_id=rp.semester_id
            where st.user_id=%s and (%s is null or s.semester_id=%s)
            order by s.start_date desc, c.course_code
        """, (student["user_id"], semester_id, semester_id)))
    finally:
        db.close()
