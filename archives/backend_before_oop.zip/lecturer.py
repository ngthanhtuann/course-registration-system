from flask import Blueprint, jsonify, request
from auth import require_auth, get_current_user
from database import get_db

lecturer_bp = Blueprint("lecturer", __name__, url_prefix="/api/lecturer")


@lecturer_bp.get("/profile")
@require_auth("lecturer")
def profile():
    user=get_current_user(); db=get_db()
    try:
        row=db.fetch_one("""select l.lecturer_id, u.user_id, u.username, u.fullname, u.email, u.role,
            coalesce(array_agg(q.course_code) filter (where q.course_code is not null), '{}') as qualifications
            from lecturers l join users u on u.user_id=l.user_id
            left join lecturer_qualifications q on q.lecturer_id=l.lecturer_id
            where l.user_id=%s group by l.lecturer_id,u.user_id,u.username,u.fullname,u.email,u.role""", (user["user_id"],))
        return (jsonify(row),200) if row else (jsonify({"error":"lecturer profile not found"}),404)
    finally: db.close()

@lecturer_bp.get("/semesters")
@require_auth("lecturer")
def semesters():
    db=get_db()
    try: return jsonify(db.fetch_all("select semester_id, semester_name, start_date, end_date, status from semesters order by start_date desc"))
    finally: db.close()

@lecturer_bp.get("/teaching-courses")
@require_auth("lecturer")
def teaching_courses():
    lecturer = get_current_user()
    semester_id = request.args.get("semester_id")
    if not semester_id:
        return jsonify({"error": "semester_id is required"}), 400
    db = get_db()
    try:
        return jsonify(db.fetch_all("""
            select ta.assignment_id, c.course_code, c.course_name, c.credit,
                   c.prerequisite_course_code,
                   (select count(*) from registrations r join registration_periods rp on rp.period_id=r.period_id
                    where r.course_code=c.course_code and rp.semester_id=ta.semester_id and r.registration_status='registered') as student_count
            from teaching_assignments ta
            join lecturers l on l.lecturer_id=ta.lecturer_id
            join courses c on c.course_code=ta.course_code
            where l.user_id=%s and ta.semester_id=%s
            order by c.course_code
        """, (lecturer["user_id"], semester_id)))
    finally:
        db.close()


@lecturer_bp.get("/courses/<course_code>/students")
@require_auth("lecturer")
def course_students(course_code):
    lecturer = get_current_user()
    semester_id = request.args.get("semester_id")
    db = get_db()
    try:
        allowed = db.fetch_one("""
            select 1 from teaching_assignments ta
            join lecturers l on l.lecturer_id=ta.lecturer_id
            where l.user_id=%s and ta.semester_id=%s and ta.course_code=%s
        """, (lecturer["user_id"], semester_id, course_code))
        if not allowed:
            return jsonify({"error": "course is not assigned to this lecturer"}), 403
        return jsonify(db.fetch_all("""
            select st.student_id, u.fullname, u.email,
                   r.registration_id, r.grade, r.result_status,
                   case when c.prerequisite_course_code is null then 'Satisfied'
                        when exists (select 1 from registrations pr where pr.student_id=st.student_id and pr.course_code=c.prerequisite_course_code and pr.result_status='passed') then 'Satisfied'
                        else 'Not Satisfied' end as prerequisite_status
            from registrations r
            join students st on st.student_id=r.student_id
            join users u on u.user_id=st.user_id
            join courses c on c.course_code=r.course_code
            join registration_periods rp on rp.period_id=r.period_id
            where r.course_code=%s and rp.semester_id=%s and r.registration_status='registered'
            order by st.student_id
        """, (course_code, semester_id)))
    finally:
        db.close()


@lecturer_bp.put("/registrations/<registration_id>/grade")
@require_auth("lecturer")
def update_grade(registration_id):
    lecturer = get_current_user()
    d = request.get_json() or {}
    grade = d.get("grade")
    if grade is None:
        return jsonify({"error": "grade is required"}), 400
    try:
        grade = float(grade)
    except (TypeError, ValueError):
        return jsonify({"error": "grade must be a number"}), 400
    if grade < 0 or grade > 10:
        return jsonify({"error": "grade must be between 0 and 10"}), 400

    db = get_db()
    try:
        row = db.fetch_one("""
            select r.registration_id
            from registrations r
            join registration_periods rp on rp.period_id=r.period_id
            join teaching_assignments ta on ta.course_code=r.course_code and ta.semester_id=rp.semester_id
            join lecturers l on l.lecturer_id=ta.lecturer_id
            where r.registration_id=%s and l.user_id=%s and r.registration_status='registered'
        """, (registration_id, lecturer["user_id"]))
        if not row:
            return jsonify({"error": "student is not registered in a course assigned to this lecturer"}), 403
        result_status = "passed" if grade >= 5 else "not passed"
        db.execute_query("update registrations set grade=%s, result_status=%s where registration_id=%s",
                   (grade, result_status, registration_id))
        return jsonify({"message": "grade saved successfully", "result_status": result_status})
    finally:
        db.close()
