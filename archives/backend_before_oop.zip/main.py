from flask import Flask, jsonify
from flask_cors import CORS
from auth import auth_bp
from admin import admin_bp
from student import student_bp
from lecturer import lecturer_bp

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(student_bp)
app.register_blueprint(lecturer_bp)


def ensure_schema_compatibility():
    """Apply small additive migrations needed by the current application."""
    from database import get_db
    db = get_db()
    try:
        db.execute_query("alter table users add column if not exists active_status boolean not null default true")
    finally:
        db.close()


try:
    ensure_schema_compatibility()
except Exception:
    # The API can still start when the database is temporarily unavailable;
    # the normal database error will be reported when a request is made.
    pass


@app.get("/")
def home():
    return jsonify({"message": "course registration system backend is running"})


@app.get("/api/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)