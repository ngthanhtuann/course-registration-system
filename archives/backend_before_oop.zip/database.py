import os
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

load_dotenv()


class Database:
    def __init__(self):
        self.conn = psycopg2.connect(
            host=os.getenv("db_host", "localhost"),
            port=os.getenv("db_port", "5432"),
            database=os.getenv("db_name", "course_registration_system"),
            user=os.getenv("db_user", "postgres"),
            password=os.getenv("db_password", "")
        )

    def execute_query(self, query, params=None):
        cursor = self.conn.cursor(cursor_factory=RealDictCursor)

        try:
            cursor.execute(query, params)
            self.conn.commit()
            return cursor

        except Exception:
            self.conn.rollback()
            raise

        finally:
            cursor.close()

    def execute(self, query, params=None):
        """Execute a write query inside the current transaction without auto-commit."""
        cursor = self.conn.cursor(cursor_factory=RealDictCursor)
        try:
            cursor.execute(query, params)
            return cursor
        except Exception:
            self.conn.rollback()
            raise
        finally:
            cursor.close()

    def fetch_one(self, query, params=None):
        cursor = self.conn.cursor(cursor_factory=RealDictCursor)

        try:
            cursor.execute(query, params)
            return cursor.fetchone()

        finally:
            cursor.close()

    def fetch_all(self, query, params=None):
        cursor = self.conn.cursor(cursor_factory=RealDictCursor)

        try:
            cursor.execute(query, params)
            return cursor.fetchall()

        finally:
            cursor.close()

    def close(self):
        if self.conn:
            self.conn.close()


def get_db():
    return Database()