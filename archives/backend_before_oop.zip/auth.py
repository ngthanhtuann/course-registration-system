from datetime import datetime, timedelta, timezone
from functools import wraps
import bcrypt
import jwt
from flask import Blueprint, jsonify, request
from config import JWT_ALGORITHM, JWT_EXPIRE_HOURS, JWT_SECRET
from database import get_db

auth_bp = Blueprint("auth", __name__, url_prefix="/api")


def hash_password(password):
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def check_password(password, password_hash):
    return bcrypt.checkpw(password.encode(), password_hash.encode())


def make_token(user):
    payload = {
        "user_id": user["user_id"],
        "username": user["username"],
        "role": user["role"],
        "exp": datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRE_HOURS)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def get_current_user():
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    try:
        payload = jwt.decode(header.split(" ", 1)[1], JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
        return None


def require_auth(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = get_current_user()
            if not user:
                return jsonify({"error": "authentication required"}), 401
            if roles and user["role"] not in roles:
                return jsonify({"error": "forbidden"}), 403
            db = get_db()
            try:
                active = db.fetch_one("select active_status from users where user_id=%s", (user["user_id"],))
                if not active or not active.get("active_status", True):
                    return jsonify({"error": "account is inactive"}), 403
            finally:
                db.close()
            return fn(*args, **kwargs)
        return wrapper
    return decorator


@auth_bp.post("/login")
def login():
    data = request.get_json() or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")
    if not username or not password:
        return jsonify({"error": "username and password are required"}), 400

    db = get_db()
    try:
        user = db.fetch_one(
            "select user_id, username, password, fullname, email, role, active_status from users where username = %s",
            (username,)
        )
        try:
            valid_password = bool(user and check_password(password, user["password"]))
        except (ValueError, TypeError):
            valid_password = False
        if not user or not user.get("active_status", True) or not valid_password:
            return jsonify({"error": "invalid username or password"}), 401

        token = make_token(user)
        return jsonify({
            "token": token,
            "user": {
                "user_id": user["user_id"],
                "username": user["username"],
                "fullname": user["fullname"],
                "email": user["email"],
                "role": user["role"]
            }
        })
    finally:
        db.close()


@auth_bp.get("/me")
@require_auth()
def me():
    user = get_current_user()
    db = get_db()
    try:
        result = db.fetch_one(
            "select user_id, username, fullname, email, role from users where user_id = %s",
            (user["user_id"],)
        )
        return jsonify(result or {}), 200
    finally:
        db.close()


@auth_bp.put("/account/profile")
@require_auth()
def update_profile():
    data = request.get_json() or {}
    fullname = (data.get("fullname") or "").strip()
    email = (data.get("email") or "").strip()
    if not fullname or not email:
        return jsonify({"error": "fullname and email are required"}), 400
    user = get_current_user()
    db = get_db()
    try:
        duplicate = db.fetch_one("select user_id from users where email=%s and user_id<>%s", (email, user["user_id"]))
        if duplicate:
            return jsonify({"error": "Email already exists"}), 409
        db.execute_query("update users set fullname=%s, email=%s where user_id=%s", (fullname, email, user["user_id"]))
        return jsonify({"message": "profile updated successfully"})
    finally:
        db.close()


@auth_bp.put("/account/password")
@require_auth()
def change_password():
    data = request.get_json() or {}
    current = data.get("current_password", "")
    new_password = data.get("new_password", "")
    if not current or not new_password:
        return jsonify({"error": "current_password and new_password are required"}), 400
    if len(new_password) < 8:
        return jsonify({"error": "new password must contain at least 8 characters"}), 400

    user = get_current_user()
    db = get_db()
    try:
        row = db.fetch_one("select password from users where user_id = %s", (user["user_id"],))
        if not row or not check_password(current, row["password"]):
            return jsonify({"error": "current password is incorrect"}), 400
        db.execute_query(
            "update users set password = %s where user_id = %s",
            (hash_password(new_password), user["user_id"])
        )
        return jsonify({"message": "password changed successfully"})
    finally:
        db.close()
